package com.data;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieBookingSystem1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
